
  # UniStay KSA Platform Design

  This is a code bundle for UniStay KSA Platform Design. The original project is available at https://www.figma.com/design/Pl9Rb9F2Gw0bYMqdO9ncY9/UniStay-KSA-Platform-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  